import os
import shlex
import subprocess


SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def _resolve_helper_path():
    system_helper = "/usr/libexec/goldendog-firewall/ufw-apply"
    dev_helper = os.path.join(SCRIPT_DIR, "..", "helpers", "ufw-apply")

    if os.path.exists(system_helper):
        return system_helper
    if os.path.exists(dev_helper):
        return dev_helper
    return ""


def _read_shell_vars(path):
    values = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, val = line.split("=", 1)
            values[key.strip()] = val.strip().strip('"').strip("'")
    return values


def read_firewall_state():
    """
    Read the configured UFW state without root privileges
    (/etc/ufw/ufw.conf and /etc/default/ufw are world-readable).
    Returns dict(enabled, incoming, outgoing) with policies "allow"/"deny",
    or None if the files cannot be read.
    """
    try:
        conf = _read_shell_vars("/etc/ufw/ufw.conf")
        defaults = _read_shell_vars("/etc/default/ufw")
    except OSError:
        return None

    def policy(value):
        return "deny" if value.upper() in ("DROP", "REJECT") else "allow"

    return {
        "enabled": conf.get("ENABLED", "no").lower() == "yes",
        "incoming": policy(defaults.get("DEFAULT_INPUT_POLICY", "DROP")),
        "outgoing": policy(defaults.get("DEFAULT_OUTPUT_POLICY", "ACCEPT")),
    }


def list_network_interfaces():
    """Return interface names for dropdowns, excluding loopback."""
    base = "/sys/class/net"
    try:
        names = []
        for name in sorted(os.listdir(base)):
            if name == "lo":
                continue
            names.append(name)
        return names
    except Exception:
        return []


def _run_command(command, stdin_text=None):
    """Run a command; returns (ok, stdout, error_details)."""
    try:
        result = subprocess.run(
            command,
            input=stdin_text if stdin_text is not None else "",
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError as e:
        return False, "", str(e)
    if result.returncode != 0:
        stderr = (result.stderr or "").strip()
        stdout = (result.stdout or "").strip()
        details = stderr if stderr else stdout
        # pkexec: 126 = authentication dismissed, 127 = not authorized
        if result.returncode in (126, 127) and command and command[0] == "pkexec":
            details = "cancelled"
        return False, stdout, details or "Unknown error"
    return True, result.stdout or "", ""


def _helper_command(*args):
    """The helper runs as root: through pkexec, or directly if we already are root."""
    helper_path = _resolve_helper_path()
    if not helper_path:
        return None
    if os.geteuid() == 0:
        return [helper_path, *args]
    return ["pkexec", helper_path, *args]


def list_rules():
    """
    The user rules ufw has, as "ufw show added" prints them (without "ufw ").
    Needs root (asks for the administrator password).
    Returns (ok, rules_or_error): a list of strings, or the error ("cancelled"
    if the password dialog was dismissed).
    """
    cmd = _helper_command("list")
    if cmd is None:
        return False, "Helper script not found: /usr/libexec/goldendog-firewall/ufw-apply"
    ok, stdout, error = _run_command(cmd)
    if not ok:
        return False, error
    return True, [line.strip() for line in stdout.splitlines() if line.strip()]


def split_rule(rule):
    """
    (rule_without_comment, comment) for a rule as list_rules() returns it,
    e.g. "allow 9090/tcp comment 'Cockpit'" -> ("allow 9090/tcp", "Cockpit").
    """
    try:
        parts = shlex.split(rule)
    except ValueError:
        return rule, ""
    if len(parts) >= 2 and parts[-2] == "comment":
        return " ".join(shlex.quote(p) for p in parts[:-2]), parts[-1]
    return rule, ""


def apply_firewall_configuration(enabled, incoming_policy, outgoing_policy,
                                 add_arg_sets, delete_rules=()):
    """
    Apply the firewall state, default policies and rule changes in one
    privileged call.
    add_arg_sets: list of ufw argument lists to add (without the ufw binary).
    delete_rules: rules to delete, exactly as list_rules() returned them.
    Returns (ok, message); message is "cancelled" if the password dialog was
    dismissed.
    """
    enabled_val = "on" if enabled else "off"
    incoming_val = "allow" if incoming_policy == "allow" else "deny"
    outgoing_val = "allow" if outgoing_policy == "allow" else "deny"

    cmd = _helper_command(enabled_val, incoming_val, outgoing_val)
    if cmd is None:
        return False, "Helper script not found: /usr/libexec/goldendog-firewall/ufw-apply"

    # One change per line, tab-separated; the helper checks all of them
    # before applying anything.
    lines = ["delete\t" + rule for rule in delete_rules]
    lines += ["add\t" + "\t".join(arg_set) for arg_set in add_arg_sets]
    changes = "".join(line + "\n" for line in lines)

    ok, _stdout, error = _run_command(cmd, stdin_text=changes)
    if not ok:
        return False, error
    return True, "Applied firewall settings with helper."
