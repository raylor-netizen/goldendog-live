# GoldenDog Linux by Alexia Michelle <alexia@goldendoglinux.org>
# GNU GPL v3.0
"""
Rule logic without GTK, so it can be tested on its own.

- build_simple_args / build_advanced_args: the ufw arguments for the fields
  of the "Simple" and "Advanced" tabs of the rule dialog.
- parse_rule: the opposite, a rule as "ufw show added" prints it turned back
  into the dialog fields, so a rule already in the firewall can be edited.

The interface field uses None for "all interfaces" (the dialog shows a
translated label for it).
"""
import shlex

POLICIES = ("allow", "deny", "reject")
DIRECTIONS = ("in", "out")
PROTOCOLS = ("tcp", "udp")


def _directions(direction):
    return ["in", "out"] if direction == "both" else [direction]


def build_simple_args(policy, direction, protocol, interface, port):
    """ufw argument lists (one per direction) for the Simple tab."""
    arg_sets = []
    for current in _directions(direction):
        args = [policy, current]
        if interface:
            args += ["on", interface]
        if port:
            args += ["to", "any", "port", port]
        if protocol != "both":
            args += ["proto", protocol]
        arg_sets.append(args)
    return arg_sets


def build_advanced_args(policy, direction, protocol, interface,
                        from_ip, from_port, to_ip, to_port):
    """ufw argument lists (one per direction) for the Advanced tab."""
    arg_sets = []
    for current in _directions(direction):
        args = [policy, current]
        if interface:
            args += ["on", interface]
        if protocol != "both":
            args += ["proto", protocol]
        args += ["from", from_ip or "any"]
        if from_port:
            args += ["port", from_port]
        args += ["to", to_ip or "any"]
        if to_port:
            args += ["port", to_port]
        arg_sets.append(args)
    return arg_sets


def ports_need_protocol(protocol, *ports):
    """
    True when a port range or list (1000:2000, 80,443) is used with protocol
    "both": ufw only accepts those with tcp or udp.
    """
    return protocol == "both" and any(p and (":" in p or "," in p) for p in ports)


def _is_portspec(text):
    """Ports as ufw prints them: 22, 1000:2000, 80,443 (digits, ':' and ',')."""
    return bool(text) and all(c.isdigit() or c in ":," for c in text) \
        and all(part for part in text.replace(":", ",").split(","))


def parse_rule(rule):
    """
    The dialog fields of a rule as "ufw show added" prints it (without the
    leading "ufw "), or None when the dialog cannot represent it: "limit",
    application profiles ("allow OpenSSH"), "route" rules, logging options...

    Returns a dict with: mode ("simple"/"advanced"), name, policy, direction,
    protocol ("tcp"/"udp"/"both"), interface (None = all), and port (simple)
    or from_ip, from_port, to_ip, to_port (advanced; "" = any).
    """
    try:
        tokens = shlex.split(rule)
    except ValueError:
        return None

    name = ""
    if len(tokens) >= 2 and tokens[-2] == "comment":
        name = tokens[-1]
        tokens = tokens[:-2]

    if not tokens or tokens[0] not in POLICIES:
        return None
    policy = tokens[0]
    i = 1

    direction = "in"
    if i < len(tokens) and tokens[i] in DIRECTIONS:
        direction = tokens[i]
        i += 1

    rest = tokens[i:]

    # Short form: "allow 22/tcp", "deny out 25", "allow 80,443/tcp"
    if len(rest) == 1 and rest[0] not in ("on", "from", "to", "proto"):
        ports, _sep, proto = rest[0].partition("/")
        if not _is_portspec(ports) or (proto and proto not in PROTOCOLS):
            return None        # e.g. an application profile like OpenSSH
        return {
            "mode": "simple", "name": name, "policy": policy,
            "direction": direction, "protocol": proto or "both",
            "interface": None, "port": ports,
        }

    # Long form: [on IFACE] [from ADDR [port P]] [to ADDR [port P]] [proto X]
    fields = {"on": None, "from": None, "from_port": None,
              "to": None, "to_port": None, "proto": None}
    last_addr = None
    j = 0
    while j < len(rest):
        key = rest[j]
        if j + 1 >= len(rest):
            return None
        val = rest[j + 1]
        if key in ("on", "from", "to", "proto"):
            if fields[key] is not None:
                return None
            fields[key] = val
            last_addr = key if key in ("from", "to") else None
        elif key == "port" and last_addr:
            if fields[last_addr + "_port"] is not None or not _is_portspec(val):
                return None
            fields[last_addr + "_port"] = val
            last_addr = None
        else:
            return None        # app, route, log, a second "on"...
        j += 2

    if fields["proto"] is not None and fields["proto"] not in PROTOCOLS:
        return None
    protocol = fields["proto"] or "both"

    def addr(value):
        return "" if value in (None, "any") else value

    from_ip, to_ip = addr(fields["from"]), addr(fields["to"])
    from_port, to_port = fields["from_port"] or "", fields["to_port"] or ""

    if not from_ip and not from_port and not to_ip:
        return {
            "mode": "simple", "name": name, "policy": policy,
            "direction": direction, "protocol": protocol,
            "interface": fields["on"], "port": to_port,
        }
    return {
        "mode": "advanced", "name": name, "policy": policy,
        "direction": direction, "protocol": protocol,
        "interface": fields["on"], "from_ip": from_ip, "from_port": from_port,
        "to_ip": to_ip, "to_port": to_port,
    }


def args_for(data):
    """ufw argument lists for parsed or dialog data (see parse_rule)."""
    if data["mode"] == "simple":
        return build_simple_args(data["policy"], data["direction"], data["protocol"],
                                 data["interface"], data["port"])
    return build_advanced_args(data["policy"], data["direction"], data["protocol"],
                               data["interface"], data["from_ip"], data["from_port"],
                               data["to_ip"], data["to_port"])
