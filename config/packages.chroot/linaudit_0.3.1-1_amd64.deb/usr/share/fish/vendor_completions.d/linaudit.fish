complete -c linaudit -l profile -d 'System profile. Without it, a menu is shown if there is a terminal; otherwise it is auto-detected.' -r -f -a "auto\t''
server\t''
desktop\t''
container\t''"
complete -c linaudit -l category -d 'Run only these categories (e.g. ssh,accounts).' -r
complete -c linaudit -l waivers -d 'Extra waivers file, besides /etc/linaudit/waivers.conf.' -r -F
complete -c linaudit -l output -d 'Save the report to FILE (mode 600) instead of printing it.' -r -F
complete -c linaudit -l min-score -d 'Exit code 1 if the score is lower than N (useful in cron/CI).' -r
complete -c linaudit -l lang -d 'Interface language: es or en. By default, the one chosen on the welcome screen or the system locale.' -r
complete -c linaudit -l completions -d 'Generate shell completions (bash, zsh, fish...) and exit.' -r -f -a "bash\t''
elvish\t''
fish\t''
powershell\t''
zsh\t''"
complete -c linaudit -s y -l no-interactive -d 'Do not show the profile menu even with a terminal (use auto-detection).'
complete -c linaudit -l list-profiles -d 'List the available profiles and exit.'
complete -c linaudit -l list-categories -d 'List the available categories and exit.'
complete -c linaudit -l json -d 'JSON output (for a central collector).'
complete -c linaudit -l plain -d 'Text report instead of the interactive interface (TUI).'
complete -c linaudit -l all -d 'Also include passed checks (in the TUI: start by showing all of them).'
complete -c linaudit -l fast -d 'Skip the full filesystem sweeps (SUID, world-writable, etc.).'
complete -c linaudit -l no-color -d 'No colors (NO_COLOR is honored too).'
complete -c linaudit -s h -l help -d 'Show this help.'
complete -c linaudit -s V -l version -d 'Show the version.'
