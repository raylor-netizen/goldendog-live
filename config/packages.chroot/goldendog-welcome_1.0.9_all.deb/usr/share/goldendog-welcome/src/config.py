import os
import subprocess

# Paths (can be overridden for testing)
CONFIG_DIR = os.path.expanduser("~/.config/goldendog-welcome")
EULA_MARKER = os.path.expanduser("~/.eula_agreed")
POPCON_CONF = "/etc/popularity-contest.conf"

# Every system-wide change goes through this single helper, shipped by
# goldendog-security-center (polkit action org.goldendog.security-center.apply,
# shared by both apps): the administrator password is asked once and kept for a
# few minutes.
SYSTEM_HELPER = "/usr/libexec/goldendog-security-center/apply-settings"
DEV_HELPER = os.path.join(os.path.dirname(__file__), "..", "..",
                          "goldendog-security-center", "helpers", "apply-settings")

# systemd units of the remote access services offered in the welcome
REMOTE_UNITS = {
    "ssh": "ssh.service",
    "cockpit": "cockpit.socket",
}


def _helper_path():
    if os.path.exists(SYSTEM_HELPER):
        return SYSTEM_HELPER
    if os.path.exists(DEV_HELPER):
        return DEV_HELPER
    return None


def _run_helper(settings):
    """
    Apply system settings as root through pkexec.
    settings: dict of KEY -> VALUE accepted by apply-settings (only what changed).
    Returns True on success (or when there is nothing to apply).
    """
    if not settings:
        return True

    helper_path = _helper_path()
    if not helper_path:
        print(f"Error: helper not found at {SYSTEM_HELPER}")
        return False

    cmd = ["pkexec", helper_path] + [f"{k}={v}" for k, v in settings.items()]
    print(f"Applying system settings: {' '.join(cmd[2:])}")
    try:
        result = subprocess.run(cmd, check=True, capture_output=True, text=True)
        if result.stdout.strip():
            print(f"Helper stdout: {result.stdout.strip()}")
        if result.stderr.strip():
            print(f"Helper stderr: {result.stderr.strip()}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"Failed to apply system settings (user cancelled?): {e}")
        if e.stdout:
            print(f"Helper stdout: {e.stdout.strip()}")
        if e.stderr:
            print(f"Helper stderr: {e.stderr.strip()}")
        return False
    except FileNotFoundError:
        print("pkexec not found.")
        return False


def _firewall_settings(enabled, block_incoming, block_outgoing):
    return {
        "firewall": "on" if enabled else "off",
        "incoming": "deny" if block_incoming else "allow",
        "outgoing": "deny" if block_outgoing else "allow",
    }


def _changed_firewall_settings(enabled, block_incoming, block_outgoing):
    """Only the firewall settings that differ from the current configuration."""
    wanted = _firewall_settings(enabled, block_incoming, block_outgoing)
    state = read_firewall_state()
    if state is None:
        return wanted
    current = _firewall_settings(state["enabled"], state["block_incoming"], state["block_outgoing"])
    return {k: v for k, v in wanted.items() if current[k] != v}


def _changed_remote_settings(ssh, cockpit):
    """Only the remote access settings that differ from the current state."""
    state = read_remote_access_state()
    changes = {}
    for key, wanted in (("ssh", ssh), ("cockpit", cockpit)):
        if wanted is None or not state[key]["installed"]:
            continue
        if state[key]["enabled"] != wanted:
            changes[key] = "on" if wanted else "off"
    return changes


def save_preferences(eula_accepted, plasma_telemetry, debian_telemetry,
                     firewall_enabled, block_incoming, block_outgoing,
                     ssh_enabled=None, cockpit_enabled=None):
    """
    Save the user's preferences and apply settings.
    System-wide changes are applied in a single privileged call, and only
    the ones that differ from the current state (no prompt if none).
    """
    if not eula_accepted:
        # Should not happen if UI is correct, but safety check
        return False

    # 1. Mark EULA as accepted
    try:
        with open(EULA_MARKER, 'w') as f:
            f.write("agreed\n")
    except IOError as e:
        print(f"Error saving EULA marker: {e}")

    # 2. Apply Plasma Telemetry (per user, no privileges needed)
    _apply_plasma_telemetry(plasma_telemetry)

    # 3. System settings: popularity-contest, firewall, remote access
    settings = {}
    popcon = read_popcon_participate()
    wanted_popcon = "yes" if debian_telemetry else "no"
    if popcon is None:
        print(f"Popularity contest config not found at {POPCON_CONF}, skipping Debian telemetry.")
    elif popcon != wanted_popcon:
        settings["popcon"] = wanted_popcon
    settings.update(_changed_firewall_settings(firewall_enabled, block_incoming, block_outgoing))
    settings.update(_changed_remote_settings(ssh_enabled, cockpit_enabled))

    if not _run_helper(settings):
        print("System settings were not applied successfully.")
        return False

    # 4. Disable this welcome app from running again
    disable_autostart()

    return True


def _apply_plasma_telemetry(enabled):
    """
    Configure KDE Plasma User Feedback.
    Target: ~/.config/PlasmaUserFeedback
    If enabled:
      [Global]
      FeedbackLevel=32
    If disabled:
      File is emptied (touched).
    """
    config_path = os.path.expanduser("~/.config/PlasmaUserFeedback")

    try:
        with open(config_path, 'w') as f:
            if enabled:
                f.write("[Global]\nFeedbackLevel=32\n")
            else:
                # Just open/close writes an empty file (truncates it)
                pass
        print(f"Plasma Telemetry applied: {'32 (Fair)' if enabled else 'Disabled'}")
    except IOError as e:
        print(f"Error writing Plasma telemetry config: {e}")


def _read_shell_vars(path):
    values = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, val = line.split("=", 1)
            values[key.strip()] = val.strip().strip('"').strip("'")
    return values


def read_popcon_participate():
    """'yes'/'no' from /etc/popularity-contest.conf, or None if not installed."""
    try:
        return _read_shell_vars(POPCON_CONF).get("PARTICIPATE", "no").lower()
    except OSError:
        return None


def read_firewall_state():
    """
    Read the configured UFW state without root privileges
    (/etc/ufw/ufw.conf and /etc/default/ufw are world-readable).
    Returns dict(enabled, block_incoming, block_outgoing) or None if unknown.
    """
    try:
        conf = _read_shell_vars("/etc/ufw/ufw.conf")
        defaults = _read_shell_vars("/etc/default/ufw")
    except OSError:
        return None

    def blocks(policy):
        return policy.upper() in ("DROP", "REJECT")

    return {
        "enabled": conf.get("ENABLED", "no").lower() == "yes",
        "block_incoming": blocks(defaults.get("DEFAULT_INPUT_POLICY", "DROP")),
        "block_outgoing": blocks(defaults.get("DEFAULT_OUTPUT_POLICY", "ACCEPT")),
    }


def _unit_state(unit):
    """
    (installed, enabled) for a systemd unit, without root privileges.
    'enabled' also counts a unit that is running even if not enabled.
    """
    try:
        res = subprocess.run(["systemctl", "is-enabled", unit],
                             capture_output=True, text=True, check=False)
    except FileNotFoundError:
        return False, False
    status = res.stdout.strip()
    if not status or status == "not-found" or "No such file" in res.stderr:
        return False, False
    enabled = status in ("enabled", "enabled-runtime", "static", "alias")
    if not enabled:
        active = subprocess.run(["systemctl", "is-active", unit],
                                capture_output=True, text=True, check=False)
        enabled = active.stdout.strip() == "active"
    return True, enabled


def read_remote_access_state():
    """
    State of the remote access services:
    {"ssh": {"installed": bool, "enabled": bool}, "cockpit": {...}}
    """
    state = {}
    for key, unit in REMOTE_UNITS.items():
        installed, enabled = _unit_state(unit)
        state[key] = {"installed": installed, "enabled": enabled}
    return state


def apply_firewall_settings(enabled, block_incoming, block_outgoing):
    """
    Public wrapper so UI can apply firewall choices immediately
    without saving all onboarding preferences.
    """
    return _run_helper(_changed_firewall_settings(enabled, block_incoming, block_outgoing))


def apply_remote_access(ssh_enabled, cockpit_enabled):
    """Turn the SSH server / Cockpit on or off (only what changed)."""
    return _run_helper(_changed_remote_settings(ssh_enabled, cockpit_enabled))


def disable_autostart():
    """
    Disable the autostart entry for this welcome screen.
    """
    autostart_dir = os.path.expanduser("~/.config/autostart")
    os.makedirs(autostart_dir, exist_ok=True)

    desktop_file = os.path.join(autostart_dir, "goldendog-welcome.desktop")
    # Create a file that overrides the system one.

    content = """[Desktop Entry]
Type=Application
Name=GoldenDog Welcome
Hidden=true
"""
    try:
        with open(desktop_file, 'w') as f:
            f.write(content)
    except IOError as e:
        print(f"Failed to disable autostart: {e}")
