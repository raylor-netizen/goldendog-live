import gi

gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')

from gi.repository import Gtk, Adw, Gdk
import os
import gettext
import locale
import json
import urllib.request
import urllib.error
import threading
import subprocess

SECURITY_URL_EN = "https://www.goldendoglinux.org/security"
SECURITY_URL_ES = "https://www.goldendoglinux.org/es/security"

# Setup i18n
# We look for the 'locale' directory in system path first, then relative
SYSTEM_LOCALE_DIR = "/usr/share/locale"
LOCAL_LOCALE_DIR = os.path.join(os.path.dirname(__file__), "..", "locale")

if os.path.exists(os.path.join(SYSTEM_LOCALE_DIR, "es", "LC_MESSAGES", "goldendog-welcome.mo")):
    LOCALE_DIR = SYSTEM_LOCALE_DIR
else:
    LOCALE_DIR = LOCAL_LOCALE_DIR

gettext.bindtextdomain('goldendog-welcome', LOCALE_DIR)
gettext.textdomain('goldendog-welcome')
_ = gettext.gettext

class GoldenDogWelcomeWindow(Adw.ApplicationWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.set_title(_("Welcome to GoldenDog Linux"))
        self.set_icon_name("gdl-icon")
        # Set fixed size to prevent the issue of seeing multiple slides when maximized
        # and to match the "small, centered" look of gnome-welcome.
        # User requested expansion to fix "sloppy" cramping and overlap issues.
        self.set_default_size(850, 650)
        self.set_resizable(False)

        # Toast Overlay
        # Adw.ApplicationWindow doesn't have add_toast in some versions, or usage requires overlay
        self.toast_overlay = Adw.ToastOverlay()
        self.set_content(self.toast_overlay)

        # Custom CSS for green toggle switches
        css_provider = Gtk.CssProvider()
        css_provider.load_from_data(b"switch:checked { background-color: #02c265; }")
        Gtk.StyleContext.add_provider_for_display(
            Gdk.Display.get_default(),
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

        # Main content box
        self.main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        # self.set_content(self.main_box) -> Moved to be child of overlay
        self.toast_overlay.set_child(self.main_box)

        # Header Bar - remove window controls if we want it to look like a strict dialog?
        # Standard Adwaita apps usually keep them. We'll keep them but the window is fixed size.
        self.header_bar = Adw.HeaderBar()
        self.header_bar.add_css_class("flat") # cleaner look
        self.main_box.append(self.header_bar)

        # Content Area - Horizontal box to hold [Prev] [Carousel] [Next]
        self.content_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        self.content_box.set_hexpand(True)
        self.content_box.set_vexpand(True)
        self.main_box.append(self.content_box)

        # Previous Button
        self.prev_btn = Gtk.Button()
        self.prev_btn.add_css_class("flat")
        self.prev_btn.set_valign(Gtk.Align.CENTER)
        self.prev_btn.set_margin_start(8)
        
        # Load custom prev icon
        prev_icon_path = os.path.join(os.path.dirname(__file__), "..", "assets", "go-previous.svg")
        if os.path.exists(prev_icon_path):
            img = Gtk.Image.new_from_file(prev_icon_path)
            # Make arrows larger (approx 2x standard)
            img.set_pixel_size(48)
            self.prev_btn.set_child(img)
        else:
            self.prev_btn.set_icon_name("go-previous-symbolic")
            
        self.prev_btn.connect("clicked", self._on_prev_clicked)
        self.content_box.append(self.prev_btn)

        # Carousel
        self.carousel = Adw.Carousel()
        self.carousel.set_hexpand(True)
        self.carousel.set_vexpand(True)
        self.carousel.connect("page-changed", self._on_page_changed)
        self.content_box.append(self.carousel)
        
        # Next Button
        self.next_btn = Gtk.Button()
        self.next_btn.add_css_class("flat")
        self.next_btn.set_valign(Gtk.Align.CENTER)
        self.next_btn.set_margin_end(8)
        
        # Load custom next icon
        next_icon_path = os.path.join(os.path.dirname(__file__), "..", "assets", "go-next.svg")
        if os.path.exists(next_icon_path):
            img = Gtk.Image.new_from_file(next_icon_path)
            # Make arrows larger (approx 2x standard)
            img.set_pixel_size(48)
            self.next_btn.set_child(img)
        else:
            self.next_btn.set_icon_name("go-next-symbolic")

        self.next_btn.connect("clicked", self._on_next_clicked)
        self.content_box.append(self.next_btn)

        # --- SLIDES ---
        self._build_welcome_slide()
        self._build_eula_slide()
        self._build_telemetry_slide()
        self._build_firewall_slide()
        self._build_remote_access_slide()
        self._build_newsletter_slide()
        self._build_finish_slide()

        # Carousel Indicator - dots at the bottom
        self.dots = Adw.CarouselIndicatorDots()
        self.dots.set_carousel(self.carousel)
        self.dots.set_margin_bottom(16)
        self.main_box.append(self.dots)
        
        # Initial button state update
        self._on_page_changed(self.carousel, 0)

    def _make_slide_icon(self, filename, fallback_icon_name, pixel_size=144):
        icon_path = os.path.join(os.path.dirname(__file__), "..", "assets", filename)

        if os.path.exists(icon_path):
            try:
                # Load SVG at the correct pixel size via rsvg for crisp rendering
                import gi
                gi.require_version('Rsvg', '2.0')
                from gi.repository import Rsvg, GdkPixbuf

                handle = Rsvg.Handle.new_from_file(icon_path)
                # Render the whole SVG document (not a sub-id fragment)
                pixbuf = handle.get_pixbuf()
                if pixbuf is None:
                    raise ValueError(f"Unable to render SVG: {icon_path}")

                # Scale to target size with high quality
                scaled = pixbuf.scale_simple(pixel_size, pixel_size, GdkPixbuf.InterpType.HYPER)
                if scaled is None:
                    raise ValueError(f"Unable to scale SVG: {icon_path}")
                texture = Gdk.Texture.new_for_pixbuf(scaled)

                picture = Gtk.Picture()
                picture.set_paintable(texture)
                picture.set_size_request(pixel_size, pixel_size)
                picture.set_halign(Gtk.Align.CENTER)
                picture.set_valign(Gtk.Align.CENTER)
                picture.set_content_fit(Gtk.ContentFit.FILL)
                return picture
            except Exception as e:
                print(f"Icon render fallback for {icon_path}: {e}")
                pass  # fall through to icon theme fallback

        # Fallback to icon theme
        image = Gtk.Image.new_from_icon_name(fallback_icon_name)
        image.set_pixel_size(pixel_size)
        image.set_halign(Gtk.Align.CENTER)
        image.set_valign(Gtk.Align.CENTER)
        return image
    
    def _build_welcome_slide(self):
        page = Adw.StatusPage()
        page.set_title(_("Welcome to GoldenDog Linux"))
        page.set_description(_("Thank you for choosing GoldenDog. Let's get you set up."))
        page.set_hexpand(True)
        page.set_vexpand(True)

        icon = self._make_slide_icon("gdl-icon.svg", "start-here-symbolic", 350)
        page.set_child(icon)

        self.carousel.append(page)

    def _build_eula_slide(self):
        page = Adw.StatusPage()
        page.set_title(_("License Agreement"))
        page.set_description(_("Please review and accept the terms to proceed."))
        # Icon removed to make more room for content
        # Force layout fill
        page.set_hexpand(True)
        page.set_vexpand(True)

        # Clamp for better layout
        clamp = Adw.Clamp()
        clamp.set_maximum_size(600)
        
        # Box for content
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        clamp.set_child(box)

        # Scrolled Window for EULA text
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_min_content_height(350)
        scrolled.set_vexpand(True)
        
        # Frame for visual containment
        frame = Gtk.Frame()
        frame.set_child(scrolled)
        box.append(frame)
        
        # Load license text
        license_path = os.path.join(os.path.dirname(__file__), "..", "assets", "agpl-3.0.txt")
        license_content = _("AGPL v3 License text could not be loaded.")
        if os.path.exists(license_path):
            try:
                with open(license_path, 'r', encoding='utf-8') as f:
                    license_content = f.read()
            except Exception as e:
                print(f"Error reading license: {e}")
        
        eula_text = Gtk.Label(label=license_content)
        eula_text.set_wrap(True)
        eula_text.set_selectable(True)
        eula_text.set_margin_top(12)
        eula_text.set_margin_bottom(12)
        eula_text.set_margin_start(12)
        eula_text.set_margin_end(12)
        # Use monospace for license text
        eula_text.add_css_class("monospace")
        scrolled.set_child(eula_text)

        # Checkbox
        self.eula_check = Gtk.CheckButton(label=_("I accept the terms of the license"))
        self.eula_check.set_halign(Gtk.Align.CENTER)
        self.eula_check.set_margin_top(12)
        box.append(self.eula_check)

        page.set_child(clamp)
        self.carousel.append(page)

    def _build_newsletter_slide(self):
        page = Adw.StatusPage()
        page.set_title(_("Stay Informed"))
        page.set_description(_("Subscribe to our newsletters to receive the latest news and security updates."))
        
        page.set_hexpand(True)
        page.set_vexpand(True)
        
        clamp = Adw.Clamp()
        clamp.set_maximum_size(600)
        
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        clamp.set_child(box)
        
        # Email Entry Group
        email_group = Adw.PreferencesGroup()
        box.append(email_group)
        
        self.email_entry = Adw.EntryRow()
        self.email_entry.set_title(_("Email Address"))
        self.email_entry.set_input_purpose(Gtk.InputPurpose.EMAIL)
        email_group.add(self.email_entry)
        
        # Newsletter Lists Group
        lists_group = Adw.PreferencesGroup()
        lists_group.set_title(_("Available Newsletters"))
        box.append(lists_group)
        
        # News List
        self.news_switch = Gtk.Switch()
        self.news_switch.set_active(False)
        self.news_switch.set_valign(Gtk.Align.CENTER)
        news_row = Adw.ActionRow()
        news_row.set_title(_("General News"))
        news_row.set_subtitle(_("Monthly updates about the project and community."))
        news_row.add_suffix(self.news_switch)
        lists_group.add(news_row)
        
        # Security List
        self.security_switch = Gtk.Switch()
        self.security_switch.set_active(False)
        self.security_switch.set_valign(Gtk.Align.CENTER)
        security_row = Adw.ActionRow()
        security_row.set_title(_("Security Updates"))
        security_row.set_subtitle(_("Urgent alerts about vulnerabilities and patches."))
        security_row.add_suffix(self.security_switch)
        lists_group.add(security_row)
        
        # Subscribe Button
        self.subscribe_btn = Gtk.Button(label=_("Subscribe"))
        self.subscribe_btn.add_css_class("pill")
        self.subscribe_btn.add_css_class("suggested-action")
        self.subscribe_btn.set_halign(Gtk.Align.CENTER)
        self.subscribe_btn.set_margin_top(12)
        self.subscribe_btn.connect("clicked", self._on_subscribe_clicked)
        box.append(self.subscribe_btn)
        
        page.set_child(clamp)
        self.carousel.append(page)

    def _on_subscribe_clicked(self, button):
        email = self.email_entry.get_text().strip()
        if not email or "@" not in email:
            toast = Adw.Toast.new(_("Please enter a valid email address."))
            self.toast_overlay.add_toast(toast)
            return
            
        news_enabled = self.news_switch.get_active()
        security_enabled = self.security_switch.get_active()
        
        if not news_enabled and not security_enabled:
            toast = Adw.Toast.new(_("Please select at least one newsletter."))
            self.toast_overlay.add_toast(toast)
            return

        # Disable UI during request
        self.subscribe_btn.set_sensitive(False)
        self.email_entry.set_sensitive(False)
        self.news_switch.set_sensitive(False)
        self.security_switch.set_sensitive(False)
        
        # Start subscription in a thread to avoid blocking UI
        thread = threading.Thread(target=self._do_subscribe, args=(email, news_enabled, security_enabled))
        thread.start()

    def _do_subscribe(self, email, news, security):
        # UUIDs
        UUIDS_EN = {
            "news": "90163d3c-64bb-4910-aa3e-dd71e0944cf6",
            "security": "57977cb6-60a6-465b-98f0-0b626847ed0d"
        }
        UUIDS_ES = {
            "news": "fadf16f3-eaa3-4549-9f34-8aa3af8d45c2",
            "security": "8a189f90-84b7-4f2c-8784-49509c895c54"
        }
        
        uuids_source = UUIDS_ES if self._is_spanish() else UUIDS_EN
        selected_uuids = []
        if news: selected_uuids.append(uuids_source["news"])
        if security: selected_uuids.append(uuids_source["security"])
        
        payload = {
            "email": email,
            "name": "",
            "list_uuids": selected_uuids,
            "confirm": True
        }

        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "GoldenDog-Welcome/1.0 (+https://goldendoglinux.org)"
        }
        
        try:
            req = urllib.request.Request(
                "https://lists.goldendoglinux.org/api/public/subscription",
                data=json.dumps(payload).encode('utf-8'),
                headers=headers,
                method='POST'
            )
            with urllib.request.urlopen(req, timeout=10) as response:
                if response.status == 200:
                    # Success
                    from gi.repository import GLib
                    GLib.idle_add(self._on_subscribe_success)
                else:
                    from gi.repository import GLib
                    GLib.idle_add(self._on_subscribe_error, _("Server returned an error."))
        except urllib.error.HTTPError as e:
            from gi.repository import GLib
            GLib.idle_add(self._on_subscribe_error, _("Server returned an error.") + f" (HTTP {e.code})")
        except Exception as e:
            from gi.repository import GLib
            GLib.idle_add(self._on_subscribe_error, str(e))

    def _on_subscribe_success(self):
        self.subscribe_btn.set_label(_("Subscribed!"))
        self.subscribe_btn.remove_css_class("suggested-action")
        self.subscribe_btn.add_css_class("success")
        toast = Adw.Toast.new(_("Subscription successful! Please check your email to confirm."))
        self.toast_overlay.add_toast(toast)
        # We don't re-enable the UI to prevent multiple subs

    def _on_subscribe_error(self, error_msg):
        self.subscribe_btn.set_sensitive(True)
        self.email_entry.set_sensitive(True)
        self.news_switch.set_sensitive(True)
        self.security_switch.set_sensitive(True)
        toast = Adw.Toast.new(_("Error: ") + error_msg)
        self.toast_overlay.add_toast(toast)

    def _build_telemetry_slide(self):
        page = Adw.StatusPage()
        page.set_title(_("Data & Privacy"))
        page.set_description(_("Choose how you want to contribute."))

        page.set_hexpand(True)
        page.set_vexpand(True)

        clamp = Adw.Clamp()
        clamp.set_maximum_size(600)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        clamp.set_child(box)

        icon = self._make_slide_icon("candado.svg", "preferences-system-privacy-symbolic", 132)
        box.append(icon)

        group = Adw.PreferencesGroup()
        group.set_description(_("Your privacy is important. No personal data is collected."))
        box.append(group)
        
        # Plasma Telemetry
        plasma_row = Adw.ActionRow()
        plasma_row.set_title(_("KDE Plasma Telemetry"))
        plasma_row.set_subtitle(_("Send anonymous usage data to KDE to help improve the desktop experience."))
        self.plasma_switch = Gtk.Switch()
        self.plasma_switch.set_active(False)
        self.plasma_switch.set_valign(Gtk.Align.CENTER)
        plasma_row.add_suffix(self.plasma_switch)
        group.add(plasma_row)
        
        # Debian Telemetry
        debian_row = Adw.ActionRow()
        debian_row.set_title(_("Debian Popularity Contest"))
        debian_row.set_subtitle(_("Submit anonymous package usage statistics to help Debian decide what to include."))
        self.debian_switch = Gtk.Switch()
        self.debian_switch.set_active(False)
        self.debian_switch.set_valign(Gtk.Align.CENTER)
        debian_row.add_suffix(self.debian_switch)
        group.add(debian_row)
        
        page.set_child(clamp)
        self.carousel.append(page)

    def _build_firewall_slide(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=24)
        page.set_hexpand(True)
        page.set_vexpand(True)

        clamp = Adw.Clamp()
        clamp.set_maximum_size(600)

        outer_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        clamp.set_child(outer_box)

        # Top section: icon on left, title/subtitle on right
        header_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=24)
        header_row.set_hexpand(True)

        icon = self._make_slide_icon("firewall.svg", "security-high-symbolic", 110)
        icon.set_halign(Gtk.Align.START)
        icon.set_valign(Gtk.Align.START)
        header_row.append(icon)

        header_text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        header_text_box.set_hexpand(True)
        header_text_box.set_valign(Gtk.Align.CENTER)

        title_label = Gtk.Label()
        title_label.set_markup("<span size='xx-large' weight='bold'>%s</span>" % _("Firewall &amp; Security"))
        title_label.set_halign(Gtk.Align.START)
        title_label.set_wrap(True)
        header_text_box.append(title_label)

        subtitle_label = Gtk.Label()
        subtitle_label.set_markup("<span size='large'>%s</span>" % _("Protect your system by enabling the firewall below."))
        subtitle_label.set_halign(Gtk.Align.START)
        subtitle_label.set_wrap(True)
        subtitle_label.add_css_class("dim-label")
        header_text_box.append(subtitle_label)

        header_row.append(header_text_box)

        outer_box.append(header_row)

        # Firewall Status group
        main_group = Adw.PreferencesGroup()
        main_group.set_title(_("Firewall Status"))

        self.firewall_enable_switch = Gtk.Switch()
        self.firewall_enable_switch.set_active(True)
        self.firewall_enable_switch.set_valign(Gtk.Align.CENTER)
        self.firewall_enable_switch.connect("notify::active", self._on_firewall_enable_changed)
        enable_row = Adw.ActionRow()
        enable_row.set_title(_("Enable firewall"))
        enable_row.set_subtitle(_("Recommended"))
        enable_row.add_suffix(self.firewall_enable_switch)
        main_group.add(enable_row)
        outer_box.append(main_group)

        # Traffic Rules group
        self.firewall_settings_group = Adw.PreferencesGroup()
        self.firewall_settings_group.set_title(_("Traffic Rules"))

        incoming_row = Adw.ActionRow()
        incoming_row.set_title(_("Incoming"))
        incoming_row.set_subtitle(_("Recommended: Deny"))
        incoming_choices = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        incoming_choices.set_valign(Gtk.Align.CENTER)
        self.firewall_incoming_allow_radio = Gtk.CheckButton(label=_("Allow"))
        self.firewall_incoming_deny_radio = Gtk.CheckButton(label=_("Deny"))
        self.firewall_incoming_deny_radio.set_group(self.firewall_incoming_allow_radio)
        self.firewall_incoming_deny_radio.set_active(True)
        incoming_choices.append(self.firewall_incoming_allow_radio)
        incoming_choices.append(self.firewall_incoming_deny_radio)
        incoming_row.add_suffix(incoming_choices)
        self.firewall_settings_group.add(incoming_row)

        outgoing_row = Adw.ActionRow()
        outgoing_row.set_title(_("Outgoing"))
        outgoing_row.set_subtitle(_("Recommended: Allow"))
        outgoing_choices = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        outgoing_choices.set_valign(Gtk.Align.CENTER)
        self.firewall_outgoing_allow_radio = Gtk.CheckButton(label=_("Allow"))
        self.firewall_outgoing_deny_radio = Gtk.CheckButton(label=_("Deny"))
        self.firewall_outgoing_deny_radio.set_group(self.firewall_outgoing_allow_radio)
        self.firewall_outgoing_allow_radio.set_active(True)
        outgoing_choices.append(self.firewall_outgoing_allow_radio)
        outgoing_choices.append(self.firewall_outgoing_deny_radio)
        outgoing_row.add_suffix(outgoing_choices)
        self.firewall_settings_group.add(outgoing_row)
        outer_box.append(self.firewall_settings_group)

        # Save button
        self.save_firewall_btn = Gtk.Button(label=_("Save settings"))
        self.save_firewall_btn.add_css_class("pill")
        self.save_firewall_btn.set_halign(Gtk.Align.END)
        self.save_firewall_btn.connect("clicked", self._on_save_firewall_clicked)
        outer_box.append(self.save_firewall_btn)

        # Goldendog Firewall link
        link_label = Gtk.Label()
        link_label.set_use_markup(True)
        link_label.set_halign(Gtk.Align.START)
        link_label.set_wrap(True)
        link_label.set_markup(_("Change these settings anytime from <a href=\"goldendog-firewall://open\">Goldendog Firewall</a>."))
        link_label.connect("activate-link", self._on_goldendog_firewall_link_activated)
        outer_box.append(link_label)

        # Security best practices page on the website (localized)
        security_url = SECURITY_URL_ES if self._is_spanish() else SECURITY_URL_EN
        security_label = Gtk.Label()
        security_label.set_halign(Gtk.Align.START)
        security_label.set_wrap(True)
        security_label.set_markup(
            _("Learn how to <a href=\"%s\">keep your system secure</a>.") % security_url
        )
        outer_box.append(security_label)

        clamp.set_child(outer_box)
        page.append(clamp)

        self.firewall_enable_row = enable_row
        self.firewall_incoming_deny_radio.connect("toggled", self._update_firewall_save_button)
        self.firewall_outgoing_deny_radio.connect("toggled", self._update_firewall_save_button)
        self._load_firewall_state()

        self.carousel.append(page)

    def _load_firewall_state(self):
        """Show the real UFW configuration instead of hardcoded defaults."""
        from config import read_firewall_state

        self.firewall_state = read_firewall_state()
        state = self.firewall_state
        if state is not None:
            self.firewall_enable_switch.set_active(state["enabled"])
            self.firewall_incoming_deny_radio.set_active(state["block_incoming"])
            self.firewall_incoming_allow_radio.set_active(not state["block_incoming"])
            self.firewall_outgoing_deny_radio.set_active(state["block_outgoing"])
            self.firewall_outgoing_allow_radio.set_active(not state["block_outgoing"])
            if state["enabled"]:
                self.firewall_enable_row.set_subtitle(_("Status: active"))
            else:
                self.firewall_enable_row.set_subtitle(_("Status: inactive (enabling it is recommended)"))

        self._on_firewall_enable_changed(self.firewall_enable_switch, None)

    def _firewall_selection(self):
        return {
            "enabled": self.firewall_enable_switch.get_active(),
            "block_incoming": self.firewall_incoming_deny_radio.get_active(),
            "block_outgoing": self.firewall_outgoing_deny_radio.get_active(),
        }

    def _update_firewall_save_button(self, *_args):
        # Only offer "Save" when the selection differs from what is applied.
        # If the state could not be read, always allow saving.
        if not hasattr(self, "save_firewall_btn"):
            return
        state = getattr(self, "firewall_state", None)
        self.save_firewall_btn.set_sensitive(
            state is None or self._firewall_selection() != state
        )

    @staticmethod
    def _is_spanish():
        # Check LANGUAGE env var first (used by gettext), then fall back to locale
        if os.environ.get('LANGUAGE', '').startswith('es'):
            return True
        try:
            lang = locale.getlocale()[0]
            return bool(lang and lang.startswith('es'))
        except Exception:
            return False

    def _on_firewall_enable_changed(self, switch, _pspec):
        if hasattr(self, "firewall_settings_group"):
            self.firewall_settings_group.set_sensitive(switch.get_active())
        self._update_firewall_save_button()

    def _on_goldendog_firewall_link_activated(self, label, uri):
        try:
            subprocess.Popen(["goldendog-firewall"])
            return True
        except Exception as e:
            toast = Adw.Toast.new(_("Unable to open Goldendog Firewall: ") + str(e))
            self.toast_overlay.add_toast(toast)
            return True

    def _on_save_firewall_clicked(self, button):
        firewall_enabled = self.firewall_enable_switch.get_active()
        block_incoming = self.firewall_incoming_deny_radio.get_active()
        block_outgoing = self.firewall_outgoing_deny_radio.get_active()

        print(
            "Save firewall clicked:",
            f"enabled={firewall_enabled}",
            f"block_incoming={block_incoming}",
            f"block_outgoing={block_outgoing}",
        )

        from config import apply_firewall_settings

        if apply_firewall_settings(firewall_enabled, block_incoming, block_outgoing):
            toast = Adw.Toast.new(_("Firewall settings saved."))
            self._load_firewall_state()
        else:
            toast = Adw.Toast.new(_("Could not save firewall settings."))

        self.toast_overlay.add_toast(toast)

    def _build_remote_access_slide(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=24)
        page.set_hexpand(True)
        page.set_vexpand(True)

        clamp = Adw.Clamp()
        clamp.set_maximum_size(600)

        outer_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)

        # Top section: icon on left, title/subtitle on right (same layout as the firewall slide)
        header_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=24)
        header_row.set_hexpand(True)

        # Same yellow padlock as the Security Center, where these settings live
        icon = self._make_slide_icon("candado.svg", "security-high-symbolic", 110)
        icon.set_halign(Gtk.Align.START)
        icon.set_valign(Gtk.Align.START)
        header_row.append(icon)

        header_text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        header_text_box.set_hexpand(True)
        header_text_box.set_valign(Gtk.Align.CENTER)

        title_label = Gtk.Label()
        title_label.set_markup("<span size='xx-large' weight='bold'>%s</span>" % _("Remote Access"))
        title_label.set_halign(Gtk.Align.START)
        title_label.set_wrap(True)
        header_text_box.append(title_label)

        subtitle_label = Gtk.Label()
        subtitle_label.set_markup("<span size='large'>%s</span>" % _(
            "Let other computers connect to this one. Leave these off unless you need them."))
        subtitle_label.set_halign(Gtk.Align.START)
        subtitle_label.set_wrap(True)
        subtitle_label.add_css_class("dim-label")
        header_text_box.append(subtitle_label)

        header_row.append(header_text_box)
        outer_box.append(header_row)

        group = Adw.PreferencesGroup()
        group.set_title(_("Services"))
        group.set_description(_("Turning a service on also opens its port in the firewall."))

        self.ssh_switch = Gtk.Switch()
        self.ssh_switch.set_valign(Gtk.Align.CENTER)
        self.ssh_row = Adw.ActionRow()
        self.ssh_row.set_title(_("SSH server"))
        self.ssh_row.add_suffix(self.ssh_switch)
        group.add(self.ssh_row)

        self.cockpit_switch = Gtk.Switch()
        self.cockpit_switch.set_valign(Gtk.Align.CENTER)
        self.cockpit_row = Adw.ActionRow()
        self.cockpit_row.set_title(_("Cockpit web console"))
        self.cockpit_row.add_suffix(self.cockpit_switch)
        group.add(self.cockpit_row)

        outer_box.append(group)

        self.save_remote_btn = Gtk.Button(label=_("Save settings"))
        self.save_remote_btn.add_css_class("pill")
        self.save_remote_btn.set_halign(Gtk.Align.END)
        self.save_remote_btn.connect("clicked", self._on_save_remote_clicked)
        outer_box.append(self.save_remote_btn)

        # Where to find these settings later
        security_center_label = Gtk.Label()
        security_center_label.set_halign(Gtk.Align.START)
        security_center_label.set_wrap(True)
        security_center_label.set_markup(
            _("You can change this later in the <a href=\"security-center\">Security Center</a>."))
        security_center_label.connect("activate-link", self._on_security_center_link_activated)
        outer_box.append(security_center_label)

        clamp.set_child(outer_box)
        page.append(clamp)

        self.ssh_switch.connect("notify::active", self._update_remote_save_button)
        self.cockpit_switch.connect("notify::active", self._update_remote_save_button)
        self._load_remote_access_state()

        self.carousel.append(page)

    def _load_remote_access_state(self):
        """Show the real state of the SSH server and Cockpit (off by default on new installs)."""
        from config import read_remote_access_state

        self.remote_state = read_remote_access_state()
        rows = (
            ("ssh", self.ssh_row, self.ssh_switch,
             _("Remote terminal access on port 22. Use a strong password or SSH keys.")),
            ("cockpit", self.cockpit_row, self.cockpit_switch,
             _("Manage this computer from a web browser on port 9090.")),
        )
        for key, row, switch, description in rows:
            state = self.remote_state[key]
            switch.set_active(state["enabled"])
            switch.set_sensitive(state["installed"])
            row.set_subtitle(description if state["installed"] else _("Not installed"))

        self._update_remote_save_button()

    def _remote_selection(self):
        return {
            "ssh": self.ssh_switch.get_active(),
            "cockpit": self.cockpit_switch.get_active(),
        }

    def _update_remote_save_button(self, *_args):
        if not hasattr(self, "save_remote_btn"):
            return
        state = getattr(self, "remote_state", None)
        changed = state is None or any(
            state[k]["installed"] and state[k]["enabled"] != v
            for k, v in self._remote_selection().items()
        )
        self.save_remote_btn.set_sensitive(changed)

    def _on_security_center_link_activated(self, label, uri):
        try:
            subprocess.Popen(["goldendog-security-center"], start_new_session=True)
        except Exception as e:
            print(f"Unable to open the Security Center: {e}")
            self.toast_overlay.add_toast(Adw.Toast.new(_("Could not open the Security Center.")))
        return True

    def _on_save_remote_clicked(self, button):
        from config import apply_remote_access

        sel = self._remote_selection()
        if apply_remote_access(sel["ssh"], sel["cockpit"]):
            toast = Adw.Toast.new(_("Remote access settings saved."))
        else:
            toast = Adw.Toast.new(_("Could not save remote access settings."))
        self._load_remote_access_state()
        self.toast_overlay.add_toast(toast)

    def _build_finish_slide(self):
        page = Adw.StatusPage()
        page.set_title(_("You're All Set!"))
        page.set_description(_("Review your choices and start using your system."))

        page.set_hexpand(True)
        page.set_vexpand(True)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)

        icon = self._make_slide_icon("gdl-icon.svg", "emblem-ok-symbolic", 300)
        box.append(icon)

        btn = Gtk.Button(label=_("Start Using GoldenDog"))
        btn.add_css_class("pill")
        btn.add_css_class("suggested-action")
        btn.set_halign(Gtk.Align.CENTER)
        btn.set_margin_top(8)
        btn.connect("clicked", self._on_finish_clicked)
        box.append(btn)

        page.set_child(box)

        self.carousel.append(page)

    def _on_finish_clicked(self, button):
        # Validation
        if not self.eula_check.get_active():
            # Show error or toast
            toast = Adw.Toast.new(_("You must accept the license agreement to proceed."))
            self.toast_overlay.add_toast(toast)
            # Scroll back to EULA page (index 1)
            self.carousel.scroll_to(self.carousel.get_nth_page(1), True)
            return

        # Get telemetry states
        # We need to access the switches. I'll need to store references to them in _build_telemetry_slide
        plasma = self.plasma_switch.get_active()
        debian = self.debian_switch.get_active()
        firewall_enabled = self.firewall_enable_switch.get_active()
        block_incoming = self.firewall_incoming_deny_radio.get_active()
        block_outgoing = self.firewall_outgoing_deny_radio.get_active()
        print(
            "UI firewall selection:",
            f"enabled={firewall_enabled}",
            f"block_incoming={block_incoming}",
            f"block_outgoing={block_outgoing}",
        )

        remote = self._remote_selection()

        from config import save_preferences
        if save_preferences(True, plasma, debian, firewall_enabled, block_incoming, block_outgoing,
                            ssh_enabled=remote["ssh"], cockpit_enabled=remote["cockpit"]):
            print("Settings saved.")
            self.close()
        else:
            toast = Adw.Toast.new(_("Error saving settings."))
            self.toast_overlay.add_toast(toast)

    def _on_prev_clicked(self, button):
        idx = self.carousel.get_position()
        if idx > 0:
            self.carousel.scroll_to(self.carousel.get_nth_page(idx - 1), True)

    def _on_next_clicked(self, button):
        idx = self.carousel.get_position()
        n_pages = self.carousel.get_n_pages()
        if idx < n_pages - 1:
            self.carousel.scroll_to(self.carousel.get_nth_page(idx + 1), True)

    def _on_page_changed(self, carousel, index):
        # Update button states based on current page
        idx = carousel.get_position()
        n_pages = carousel.get_n_pages()
        
        # Simple sensitivity/visibility
        self.prev_btn.set_sensitive(idx > 0)
        
        # On last page, next button could be hidden or disabled since we have a big "Finish" button
        if idx >= n_pages - 1:
            self.next_btn.set_opacity(0)
            self.next_btn.set_sensitive(False)
        else:
            self.next_btn.set_opacity(1)
            self.next_btn.set_sensitive(True)
