/*
 * GoldenDog Plasma Splash Screen
 * License: GPL 3.0
 * Author: Alexia Michelle
 */

import QtQuick 2.5


Rectangle {
    property int stage
    id: root
    color: "black"

    OpacityAnimator {
        id: introAnimation
        running: false
        target: content
        from: 0
        to: 1
        duration: 1000
        easing.type: Easing.InOutQuad
    }

    Item {
        id: content
        anchors.fill: parent
        opacity: 0

        TextMetrics {
            id: units
            text: "M"
            property int gridUnit: boundingRect.height
            property int largeSpacing: units.gridUnit
            property int smallSpacing: Math.max(2, gridUnit/4)
        }

        Image {
            id: wheelIndicator
            source: "images/wheel01.svg"
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.top: logo.bottom
            anchors.topMargin: Math.max(units.gridUnit * 1.2, logo.height * 0.07)
            property int size: Math.round(Math.max(units.gridUnit * 2.2, logo.size * 0.14))
            width: size
            height: size
            sourceSize.width: size
            sourceSize.height: size

            RotationAnimator on rotation {
                id: rotationAnimator
                from: 0
                to: 360
                duration: 800
                loops: Animation.Infinite
            }
        }

        Image {
            id: logo
            source: "images/goldendog.svg"
            smooth: true
            mipmap: true
            layer.enabled: true
            layer.smooth: true
            anchors.centerIn: parent
            property real minDim: Math.min(parent.width, parent.height)
            property real size: Math.max(units.gridUnit * 12, Math.min(minDim * 0.47, units.gridUnit * 25))
            width: size
            height: size
            sourceSize.width: Math.round(size * 1.1)
            sourceSize.height: Math.round(size * 1.1)
        }

        Text {
            id: footerText
            text: "Goldendog Linux 2 (Golden Retriever)"
            color: "#eff0f1"
            opacity: 0.9
            font.pixelSize: Math.max(12, units.gridUnit)
            anchors.right: parent.right
            anchors.bottom: parent.bottom
            anchors.rightMargin: units.gridUnit
            anchors.bottomMargin: units.gridUnit
        }
    }

    onStageChanged: {
        if (stage == 1) {
            introAnimation.running = true;
        } else if (stage == 5) {
            introAnimation.target = wheelIndicator;
            introAnimation.from = 1;
            introAnimation.to = 0;
            introAnimation.running = true;
        }
    }
}
