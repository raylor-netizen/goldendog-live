#!/usr/bin/env python3
# GoldenDog Linux by Alexia Michelle <alexia@goldendoglinux.org>
# GNU GPL v3.0
import os
import sys

# realpath: this script is symlinked to /usr/bin/goldendog-security-center
sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))

from src.application import SecurityCenterApplication

if __name__ == "__main__":
    app = SecurityCenterApplication()
    sys.exit(app.run(sys.argv))
