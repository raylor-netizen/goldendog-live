# GoldenDog Linux by Alexia Michelle <alexia@goldendoglinux.org>
# GNU GPL v3.0
"""
Read the current security and privacy state (no privileges needed) and
apply changes. System-wide changes go through a single root helper
(apply-settings, polkit action org.goldendog.security-center.apply);
the Plasma telemetry setting is per user and is written directly.
"""
import os
import shutil
import subprocess

POPCON_CONF = "/etc/popularity-contest.conf"
UFW_CONF = "/etc/ufw/ufw.conf"
UFW_DEFAULTS = "/etc/default/ufw"
PLASMA_FEEDBACK_CONF = os.path.expanduser("~/.config/PlasmaUserFeedback")
PLASMA_FEEDBACK_LEVEL = 32   # same level goldendog-welcome uses

SYSTEM_HELPER = "/usr/libexec/goldendog-security-center/apply-settings"
DEV_HELPER = os.path.join(os.path.dirname(__file__), "..", "helpers", "apply-settings")

# systemd units of the remote access services
REMOTE_UNITS = {
    "ssh": "ssh.service",
    "cockpit": "cockpit.socket",
}

# Plain HTTP on purpose: Cockpit's certificate is self-signed, so https://
# shows a browser warning, and Cockpit accepts unencrypted connections from
# localhost (traffic never leaves the machine). Remote clients still get
# redirected to HTTPS by Cockpit.
COCKPIT_URL = "http://localhost:9090"


# --- helpers ---

def _read_shell_vars(path):
    values = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, val = line.split("=", 1)
            values[key.strip()] = val.strip().strip('"').strip("'")
    return values


def _helper_path():
    if os.path.exists(SYSTEM_HELPER):
        return SYSTEM_HELPER
    if os.path.exists(DEV_HELPER):
        return DEV_HELPER
    return None


def apply_settings(settings):
    """
    Apply system settings as root through pkexec.
    settings: dict KEY -> VALUE accepted by apply-settings.
    Returns (ok, message). Nothing to apply means (True, "").
    Blocks while the password dialog is open: call it from a thread.
    """
    if not settings:
        return True, ""

    helper = _helper_path()
    if not helper:
        return False, f"helper not found: {SYSTEM_HELPER}"

    cmd = ["pkexec", helper] + [f"{k}={v}" for k, v in settings.items()]
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, check=False)
    except FileNotFoundError:
        return False, "pkexec not found"

    if res.returncode == 0:
        return True, res.stdout.strip()
    # 126/127: authentication dismissed or not authorized
    if res.returncode in (126, 127):
        return False, "cancelled"
    return False, (res.stderr.strip() or res.stdout.strip() or f"exit {res.returncode}")


# --- firewall ---

def read_firewall_state():
    """
    dict(installed, enabled, block_incoming, block_outgoing) from the ufw
    configuration files (world-readable), or installed=False.
    """
    installed = any(os.path.exists(p) for p in ("/usr/sbin/ufw", "/sbin/ufw"))
    try:
        conf = _read_shell_vars(UFW_CONF)
        defaults = _read_shell_vars(UFW_DEFAULTS)
    except OSError:
        return {"installed": False, "enabled": False,
                "block_incoming": True, "block_outgoing": False}

    def blocks(policy):
        return policy.upper() in ("DROP", "REJECT")

    return {
        "installed": installed,
        "enabled": conf.get("ENABLED", "no").lower() == "yes",
        "block_incoming": blocks(defaults.get("DEFAULT_INPUT_POLICY", "DROP")),
        "block_outgoing": blocks(defaults.get("DEFAULT_OUTPUT_POLICY", "ACCEPT")),
    }


# --- remote access ---

def _unit_state(unit):
    """
    (installed, enabled) for a systemd unit, without root privileges.
    'enabled' also counts a unit that is running even if not enabled.
    """
    try:
        res = subprocess.run(["systemctl", "is-enabled", unit],
                             capture_output=True, text=True, check=False)
    except FileNotFoundError:
        return False, False
    status = res.stdout.strip()
    if not status or status == "not-found" or "No such file" in res.stderr:
        return False, False
    enabled = status in ("enabled", "enabled-runtime", "static", "alias")
    if not enabled:
        active = subprocess.run(["systemctl", "is-active", unit],
                                capture_output=True, text=True, check=False)
        enabled = active.stdout.strip() == "active"
    return True, enabled


def read_remote_access_state():
    """{"ssh": {"installed": bool, "enabled": bool}, "cockpit": {...}}"""
    state = {}
    for key, unit in REMOTE_UNITS.items():
        installed, enabled = _unit_state(unit)
        state[key] = {"installed": installed, "enabled": enabled}
    return state


# --- automatic updates ---

def read_autoupdates_state():
    """
    dict(installed, enabled) for automatic security updates: the
    unattended-upgrades package, and APT::Periodic::Unattended-Upgrade as apt
    sees it (any apt.conf.d file can set it, so ask apt-config).
    """
    installed = os.path.exists("/usr/bin/unattended-upgrade")
    if not installed:
        return {"installed": False, "enabled": False}
    try:
        res = subprocess.run(["apt-config", "shell", "V", "APT::Periodic::Unattended-Upgrade"],
                             capture_output=True, text=True, check=False)
    except FileNotFoundError:
        return {"installed": True, "enabled": False}
    # Output: V='1' (nothing when unset)
    value = res.stdout.strip().partition("=")[2].strip("'\"")
    return {"installed": True, "enabled": value not in ("", "0")}


# --- privacy ---

def read_popcon_state():
    """dict(installed, enabled) for Debian popularity-contest."""
    try:
        participate = _read_shell_vars(POPCON_CONF).get("PARTICIPATE", "no").lower()
    except OSError:
        return {"installed": False, "enabled": False}
    return {"installed": True, "enabled": participate == "yes"}


def plasma_available():
    return "KDE" in os.environ.get("XDG_CURRENT_DESKTOP", "").upper().split(":") \
        or shutil.which("plasmashell") is not None


def read_plasma_telemetry():
    """True when KDE Plasma user feedback is on (FeedbackLevel > 0)."""
    try:
        values = _read_shell_vars(PLASMA_FEEDBACK_CONF)
    except OSError:
        return False
    try:
        return int(values.get("FeedbackLevel", "0")) > 0
    except ValueError:
        return False


def set_plasma_telemetry(enabled):
    """Per user, no privileges needed. Returns True on success."""
    try:
        os.makedirs(os.path.dirname(PLASMA_FEEDBACK_CONF), exist_ok=True)
        with open(PLASMA_FEEDBACK_CONF, "w", encoding="utf-8") as f:
            if enabled:
                f.write(f"[Global]\nFeedbackLevel={PLASMA_FEEDBACK_LEVEL}\n")
        return True
    except OSError as e:
        print(f"Could not write {PLASMA_FEEDBACK_CONF}: {e}")
        return False


# --- tools ---

def linaudit_available():
    return shutil.which("linaudit") is not None


def terminal_command(argv):
    """Command line that runs argv in a terminal emulator, or None."""
    for term, flag in (("x-terminal-emulator", "-e"), ("konsole", "-e"),
                       ("gnome-terminal", "--"), ("kgx", "--"), ("xterm", "-e")):
        if shutil.which(term):
            return [term, flag] + argv
    return None
