import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")

from gi.repository import Adw, Gio


class SecurityCenterApplication(Adw.Application):
    def __init__(self):
        super().__init__(
            application_id="org.goldendoglinux.SecurityCenter",
            flags=Gio.ApplicationFlags.DEFAULT_FLAGS,
        )
        self.connect("activate", self._on_activate)

    def _on_activate(self, app):
        win = self.props.active_window
        if not win:
            from .window import SecurityCenterWindow

            win = SecurityCenterWindow(application=app)
        win.present()
