# GoldenDog Linux by Alexia Michelle <alexia@goldendoglinux.org>
# GNU GPL v3.0
import gettext
import locale
import os
import shutil
import subprocess
import threading

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")

from gi.repository import Adw, Gdk, Gio, GLib, Gtk

from . import system

DOMAIN = "goldendog-security-center"
SYSTEM_LOCALE_DIR = "/usr/share/locale"
LOCAL_LOCALE_DIR = os.path.join(os.path.dirname(__file__), "..", "locale")
# Running from the source tree (compiled .mo files next to the code): use
# those, not the ones of the installed version. Installed, there is no
# locale/ next to the code and the system ones are used.
if os.path.exists(os.path.join(LOCAL_LOCALE_DIR, "es", "LC_MESSAGES", DOMAIN + ".mo")):
    LOCALE_DIR = LOCAL_LOCALE_DIR
else:
    LOCALE_DIR = SYSTEM_LOCALE_DIR
gettext.bindtextdomain(DOMAIN, LOCALE_DIR)
gettext.textdomain(DOMAIN)
_ = gettext.gettext

ASSETS_DIR = os.path.join(os.path.dirname(__file__), "..", "assets")
SECURITY_URL_EN = "https://www.goldendoglinux.org/security"
SECURITY_URL_ES = "https://www.goldendoglinux.org/es/security"

# Combo row items: index 0 is always "Deny"
DENY, ALLOW = 0, 1


def _is_spanish():
    if os.environ.get("LANGUAGE", "").startswith("es"):
        return True
    try:
        lang = locale.getlocale()[0]
        return bool(lang and lang.startswith("es"))
    except Exception:
        return False


class SecurityCenterWindow(Adw.ApplicationWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.set_title(_("Goldendog Linux Security Center"))
        self.set_icon_name("goldendog-security-center")
        self.set_default_size(720, 780)

        # Same green switches as goldendog-welcome
        css = Gtk.CssProvider()
        css.load_from_data(b"switch:checked { background-color: #02c265; }")
        Gtk.StyleContext.add_provider_for_display(
            Gdk.Display.get_default(), css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        self._loading = False   # True while the UI is being filled from the real state
        self._busy = False      # True while the root helper runs

        self.toast_overlay = Adw.ToastOverlay()
        toolbar = Adw.ToolbarView()
        toolbar.add_top_bar(Adw.HeaderBar())
        toolbar.set_content(self.toast_overlay)
        self.set_content(toolbar)

        self.page = Adw.PreferencesPage()
        self.toast_overlay.set_child(self.page)

        self._build_overview()
        self._build_firewall_group()
        self._build_remote_group()
        self._build_updates_group()
        self._build_privacy_group()
        self._build_tools_group()

        self.refresh()
        # Something may change from a terminal or another app: re-read on focus
        self.connect("notify::is-active", self._on_active_changed)

    # ------------------------------------------------------------------ UI

    def _build_overview(self):
        group = Adw.PreferencesGroup()
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=18)
        box.set_margin_bottom(6)

        icon_path = os.path.join(ASSETS_DIR, "goldendog-security-center.svg")
        if os.path.exists(icon_path):
            self.overview_icon = Gtk.Image.new_from_file(icon_path)
        else:
            self.overview_icon = Gtk.Image.new_from_icon_name("security-high-symbolic")
        self.overview_icon.set_pixel_size(72)
        box.append(self.overview_icon)

        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        text.set_valign(Gtk.Align.CENTER)
        text.set_hexpand(True)
        self.overview_title = Gtk.Label(xalign=0, wrap=True)
        self.overview_title.add_css_class("title-2")
        self.overview_text = Gtk.Label(xalign=0, wrap=True)
        self.overview_text.add_css_class("dim-label")
        text.append(self.overview_title)
        text.append(self.overview_text)
        box.append(text)

        group.add(box)
        self.page.add(group)

    def _build_firewall_group(self):
        group = Adw.PreferencesGroup(title=_("Firewall"))
        group.set_description(_("Blocks unwanted connections from the network."))

        self.firewall_row = Adw.SwitchRow(title=_("Enable firewall"))
        self.firewall_row.connect("notify::active", self._on_firewall_toggled)
        group.add(self.firewall_row)

        self.incoming_row = self._policy_row(_("Incoming connections"), _("Recommended: Deny"))
        self.incoming_row.connect("notify::selected", self._on_policy_changed, "incoming")
        group.add(self.incoming_row)

        self.outgoing_row = self._policy_row(_("Outgoing connections"), _("Recommended: Allow"))
        self.outgoing_row.connect("notify::selected", self._on_policy_changed, "outgoing")
        group.add(self.outgoing_row)

        self.firewall_app_row = self._link_row(
            _("Advanced rules"),
            _("Allow or block specific ports and addresses in GoldenDog Firewall."),
            self._on_open_firewall_app)
        group.add(self.firewall_app_row)

        self.page.add(group)

    def _build_remote_group(self):
        group = Adw.PreferencesGroup(title=_("Remote Access"))
        group.set_description(_("Turning a service on also opens its port in the firewall. "
                                "Leave them off unless you need them."))

        self.ssh_row = Adw.SwitchRow(title=_("SSH server"))
        self.ssh_row.connect("notify::active", self._on_remote_toggled, "ssh")
        group.add(self.ssh_row)

        self.cockpit_row = Adw.SwitchRow(title=_("Cockpit web console"))
        self.cockpit_row.connect("notify::active", self._on_remote_toggled, "cockpit")
        group.add(self.cockpit_row)

        self.open_cockpit_row = self._link_row(
            _("Open Cockpit"), system.COCKPIT_URL, self._on_open_cockpit,
            icon="adw-external-link-symbolic")
        group.add(self.open_cockpit_row)

        self.page.add(group)

    def _build_updates_group(self):
        group = Adw.PreferencesGroup(title=_("Security Updates (Recommended)"))
        group.set_description(_("Only security patches will be installed automatically, in the "
                                "background, as soon as they are available. The computer will "
                                "never restart on its own, and other updates are installed as usual."))

        self.autoupdates_row = Adw.SwitchRow(title=_("Install security updates automatically"))
        self.autoupdates_row.connect("notify::active", self._on_autoupdates_toggled)
        group.add(self.autoupdates_row)

        self.page.add(group)

    def _build_privacy_group(self):
        group = Adw.PreferencesGroup(title=_("Privacy"))
        group.set_description(_("Anonymous statistics that help improve the software. "
                                "No personal data is collected."))

        self.plasma_row = Adw.SwitchRow(
            title=_("KDE Plasma Telemetry"),
            subtitle=_("Send anonymous usage data to KDE to help improve the desktop experience."))
        self.plasma_row.connect("notify::active", self._on_plasma_toggled)
        self.plasma_row.set_visible(system.plasma_available())
        group.add(self.plasma_row)

        self.popcon_row = Adw.SwitchRow(title=_("Debian Popularity Contest"))
        self.popcon_row.connect("notify::active", self._on_popcon_toggled)
        group.add(self.popcon_row)

        self.page.add(group)

    def _build_tools_group(self):
        group = Adw.PreferencesGroup(title=_("Tools"))

        self.linaudit_row = self._link_row(
            _("Audit this computer"),
            _("Run linaudit to find security problems and learn how to fix them. "
              "It opens in a terminal and asks for your password."),
            self._on_run_linaudit, icon="utilities-terminal-symbolic")
        self.linaudit_row.set_visible(system.linaudit_available())
        group.add(self.linaudit_row)

        self.page.add(group)
        self.tools_group = group

        url = SECURITY_URL_ES if _is_spanish() else SECURITY_URL_EN
        group.add(self._link_row(
            _("Security best practices"),
            _("Tips to keep your system secure, on the GoldenDog website."),
            lambda *_a: self._open_uri(url), icon="adw-external-link-symbolic"))

    def _policy_row(self, title, subtitle):
        row = Adw.ComboRow(title=title, subtitle=subtitle)
        row.set_model(Gtk.StringList.new([_("Deny"), _("Allow")]))
        return row

    def _link_row(self, title, subtitle, callback, icon="go-next-symbolic"):
        row = Adw.ActionRow(title=title, subtitle=subtitle)
        row.set_subtitle_lines(0)
        row.set_activatable(True)
        row.add_suffix(Gtk.Image.new_from_icon_name(icon))
        row.connect("activated", callback)
        return row

    # --------------------------------------------------------------- state

    def refresh(self):
        """Fill the UI from the real system state."""
        self._loading = True
        try:
            fw = system.read_firewall_state()
            self.firewall_state = fw
            self.firewall_row.set_sensitive(fw["installed"])
            self.firewall_row.set_active(fw["enabled"])
            if not fw["installed"]:
                self.firewall_row.set_subtitle(_("Not installed"))
            elif fw["enabled"]:
                self.firewall_row.set_subtitle(_("Status: active"))
            else:
                self.firewall_row.set_subtitle(_("Status: inactive (enabling it is recommended)"))
            self.incoming_row.set_selected(DENY if fw["block_incoming"] else ALLOW)
            self.outgoing_row.set_selected(DENY if fw["block_outgoing"] else ALLOW)
            for row in (self.incoming_row, self.outgoing_row):
                row.set_sensitive(fw["installed"] and fw["enabled"])
            self.firewall_app_row.set_visible(shutil.which("goldendog-firewall") is not None)

            remote = system.read_remote_access_state()
            self.remote_state = remote
            for key, row, description in (
                    ("ssh", self.ssh_row,
                     _("Remote terminal access on port 22. Use a strong password or SSH keys.")),
                    ("cockpit", self.cockpit_row,
                     _("Manage this computer from a web browser on port 9090."))):
                st = remote[key]
                row.set_active(st["enabled"])
                row.set_sensitive(st["installed"])
                row.set_subtitle(description if st["installed"] else _("Not installed"))
            self.open_cockpit_row.set_visible(remote["cockpit"]["enabled"])

            upd = system.read_autoupdates_state()
            self.autoupdates_row.set_active(upd["enabled"])
            if not upd["installed"]:
                self.autoupdates_row.set_subtitle(
                    _("Turning it on installs the unattended-upgrades package "
                      "(needs an internet connection)."))
            elif upd["enabled"]:
                self.autoupdates_row.set_subtitle(
                    _("On: security updates are checked and installed every day."))
            else:
                self.autoupdates_row.set_subtitle(
                    _("Off: security updates are installed when you update the system."))

            pop = system.read_popcon_state()
            self.popcon_row.set_active(pop["enabled"])
            self.popcon_row.set_sensitive(pop["installed"])
            self.popcon_row.set_subtitle(
                _("Submit anonymous package usage statistics to help Debian decide what to include.")
                if pop["installed"] else _("Not installed"))

            self.plasma_row.set_active(system.read_plasma_telemetry())
        finally:
            self._loading = False
        self._update_overview()

    def _update_overview(self):
        fw = self.firewall_state
        open_services = [name for key, name in (("ssh", _("SSH server")),
                                                ("cockpit", _("Cockpit web console")))
                         if self.remote_state[key]["enabled"]]
        if fw["installed"] and fw["enabled"]:
            self.overview_title.set_label(_("Your computer is protected"))
            if open_services:
                self.overview_text.set_label(
                    _("The firewall is on. Remote access is on for: %s.") % ", ".join(open_services))
            else:
                self.overview_text.set_label(
                    _("The firewall is on and remote access is off."))
            self.overview_icon.set_opacity(1.0)
        else:
            self.overview_title.set_label(_("The firewall is off"))
            self.overview_text.set_label(
                _("Other computers on the network can reach this one. Turning the firewall on is recommended."))
            self.overview_icon.set_opacity(0.5)

    def _on_active_changed(self, *_args):
        if self.is_active() and not self._busy:
            self.refresh()

    # ------------------------------------------------------------- actions

    def _apply(self, settings, done_message, error_message=None):
        """Run the root helper in a thread; the UI goes back to the real state after."""
        if self._busy:
            return
        self._busy = True
        self.page.set_sensitive(False)

        def work():
            ok, message = system.apply_settings(settings)
            GLib.idle_add(finish, ok, message)

        def finish(ok, message):
            self._busy = False
            self.page.set_sensitive(True)
            if ok:
                self._toast(done_message)
            elif message == "cancelled":
                self._toast(_("Nothing was changed."))
            else:
                print(f"apply-settings failed: {message}")
                self._toast(error_message or _("Could not change the setting."))
            self.refresh()
            return False

        threading.Thread(target=work, daemon=True).start()

    def _on_firewall_toggled(self, row, _pspec):
        if self._loading:
            return
        on = row.get_active()
        self._apply({"firewall": "on" if on else "off"},
                    _("Firewall turned on.") if on else _("Firewall turned off."))

    def _on_policy_changed(self, row, _pspec, direction):
        if self._loading:
            return
        value = "deny" if row.get_selected() == DENY else "allow"
        self._apply({direction: value}, _("Firewall settings saved."))

    def _on_remote_toggled(self, row, _pspec, key):
        if self._loading:
            return
        on = row.get_active()
        self._apply({key: "on" if on else "off"}, _("Remote access settings saved."))

    def _on_autoupdates_toggled(self, row, _pspec):
        if self._loading:
            return
        on = row.get_active()
        if on and not system.read_autoupdates_state()["installed"]:
            self._toast(_("Installing unattended-upgrades, this can take a minute…"))
        self._apply({"autoupdates": "on" if on else "off"},
                    _("Automatic updates turned on.") if on else _("Automatic updates turned off."),
                    _("Could not turn on automatic updates. Check the internet connection "
                      "and try again.") if on else None)

    def _on_popcon_toggled(self, row, _pspec):
        if self._loading:
            return
        self._apply({"popcon": "yes" if row.get_active() else "no"}, _("Privacy settings saved."))

    def _on_plasma_toggled(self, row, _pspec):
        if self._loading:
            return
        if system.set_plasma_telemetry(row.get_active()):
            self._toast(_("Privacy settings saved."))
        else:
            self._toast(_("Could not change the setting."))
            self.refresh()

    def _on_open_firewall_app(self, *_args):
        self._spawn(["goldendog-firewall"])

    def _on_open_cockpit(self, *_args):
        self._open_uri(system.COCKPIT_URL)

    def _on_run_linaudit(self, *_args):
        cmd = system.terminal_command(["sudo", "linaudit", "--profile", "desktop"])
        if cmd is None:
            self._toast(_("No terminal emulator found."))
            return
        self._spawn(cmd)

    # --------------------------------------------------------------- utils

    def _spawn(self, argv):
        try:
            subprocess.Popen(argv, start_new_session=True)
        except OSError as e:
            self._toast(_("Could not open: %s") % argv[0])
            print(f"Could not run {argv}: {e}")

    def _open_uri(self, uri):
        try:
            Gio.AppInfo.launch_default_for_uri(uri, None)
        except GLib.Error as e:
            self._toast(_("Could not open: %s") % uri)
            print(f"Could not open {uri}: {e}")

    def _toast(self, message):
        self.toast_overlay.add_toast(Adw.Toast.new(message))
